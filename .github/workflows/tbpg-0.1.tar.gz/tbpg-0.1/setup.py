from setuptools import setup, find_packages

setup(
    name='TBPG',  # نام پکیج
    version='0.1',  # نسخه پکیج
    packages=find_packages(),  # پیدا کردن خودکار پکیج‌ها
    install_requires=[

    ],
)